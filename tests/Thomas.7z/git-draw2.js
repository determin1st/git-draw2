'use strict';

const { execSync } = require('child_process');
const os = require('os');
const fs = require('fs');
const { join, sep } = require('path');

const { stdin, stdout } = process;

const username = 'determin1st';
const repo = 'git-drawing';
const heatmap = {
	'2018-12-10T23:59:59+00:00': 1,
	'2018-12-11T23:59:59+00:00': 1,
	'2018-12-12T23:59:59+00:00': 2,
	'2018-12-13T23:59:59+00:00': 2,
	'2018-12-14T23:59:59+00:00': 1,
	'2018-12-15T23:59:59+00:00': 1
};

const prefix = 'git-draw2> ';

const str = s => new Promise(resolve => (
	s.setRawMode(false),
	s.once('data', c =>
		resolve(String(c)))));

const rmDir = path =>
	!path ||
	path.length < 2 ||
	!fs.existsSync(path) ||
	(fs.readdirSync(path)
		.map(a => join(path, a))
		.forEach(p =>
			fs.lstatSync(p).isDirectory()
				? rmDir(p)
				: fs.unlinkSync(p)),
	fs.rmdirSync(path));

const typeRepoName = async def => {
	stdout.write(prefix + 'type the name of your disposable repo: ');
	const name = (await str(stdin)).trim();
	if (name && !/^[a-z]+[a-z0-9_\-]+/i.test(name)) {
		console.log(prefix + 'wrong name, try again..');
		return typeRepoName(def);
	}
	if (!name) {
		console.log(prefix + 'using default..');
		return def;
	}
	return 'https://github.com/' + username + '/' + name;
};

const yn = s => new Promise(resolve => (
	s.setRawMode(true),
	s.once('data', c =>
		resolve((s.setRawMode(false), String(c)[0].toUpperCase() === 'Y')))));

const useCustomRepo = async url => {
	console.log('');
	console.log(prefix + 'target: ' + url);
	stdout.write(prefix + 'select another repo? (Y/N): ');
	const res = await yn(stdin);
	console.log(res ? 'Yes' : 'No');
	return res ? typeRepoName(url).then(useCustomRepo) : url;
};

const shouldDraw = async () => {
	const c = Object.values(heatmap)
		.reduce((a, b) => a + b);
	if (!c) {
		console.log(prefix + 'no data, exiting..');
		return Promise.resolve();
	}
	console.log(prefix + 'ready to draw (total ' + c + ' commits)');
	stdout.write(prefix + 'press Y to continue.. ');
	const res = await yn(stdin);
	console.log('');
	if (res) {
		console.log(prefix + 'confirmed');
		return true;
	}
	console.log(prefix + 'aborted');
	return false;
};

const run = url => {
	let a, b, c, ref$;
	const tmpdir = fs.mkdtempSync(os.tmpdir() + sep);
	if (!fs.existsSync(tmpdir)) {
		console.log(prefix + 'failed to create temporary directory..');
		throw null;
	}
	console.log(prefix + 'working in: ' + tmpdir);
	execSync('git clone "' + url + '" "' + tmpdir + '"');
	if (!fs.existsSync(join(tmpdir, '.git'))) {
		console.log(prefix + 'failed to clone repository..');
		rmDir(tmpdir);
		throw null;
	}
	console.log('');
	stdout.write(prefix + 'commiting: ');
	c = {
		cwd: tmpdir,
		encoding: 'utf8'
	};
	for (a in ref$ = heatmap) {
		b = ref$[a];
		while (--b >= 0) {
			execSync('git commit -m "livescript" --allow-empty --date=' + a, c);
			stdout.write('+');
		}
	}
	console.log('');
	stdout.write(prefix + 'saving changes.. ');
	a = execSync('git push', c);
	console.log('done');
	console.log('[' + a + ']');
	console.log(prefix + 'removing: ' + tmpdir);
	rmDir(tmpdir);
	return true;
};

const cleanup = () => {
	stdin.setRawMode(false);
	stdin.pause();
	console.log('');
};

stdin.setEncoding('utf8');

(async () => {
	const url = await useCustomRepo(
		'https://github.com/' + username + '/' + repo);
	const doRun = await shouldDraw();
	if (doRun) {
		await run(url);
	}
	await cleanup();
})();
